# GoldenNest blog starter

A lightweight responsive editorial blog starter using HTML, CSS and JavaScript, with a Decap CMS admin interface scaffold.

## Before launch
1. Confirm the complete domain, including its extension (for example `goldennest.com`). The supplied name `goldennest` alone is not a complete domain.
2. Replace `YOUR-FULL-DOMAIN` in `admin/config.yml` and the canonical URL in `index.html`.
3. Create a GitHub repository and upload this project.
4. Connect the repository to Cloudflare Pages using Git integration. For this plain static site, set the build command to `exit 0` and the output directory to `/` (repository root).
5. Add your full custom domain in Cloudflare Pages and follow its DNS instructions.
6. Set up Decap Turbo, connect the GitHub repository, and replace `YOUR_DECAP_TURBO_SITE_ID` in `admin/config.yml`. The `/admin/` dashboard will not authenticate until this is completed.
7. Update the contact email, policy pages and all placeholders.
8. The demo entry is unpublished. Add original articles through the CMS after the CMS connection is configured.

## Included
- Responsive homepage and blog listing
- Search and category filter
- Individual article view
- JSON content file designed for the Decap CMS collection
- Admin interface scaffold
- About, Contact, Privacy and Disclaimer starter pages

## Important limitations
This is a starter project, not a deployed live website. No GitHub repository or Cloudflare account has been connected from this chat. AdSense approval is not guaranteed. Review the privacy policy for your actual analytics, advertising and cookie practices and seek appropriate legal guidance where needed.
